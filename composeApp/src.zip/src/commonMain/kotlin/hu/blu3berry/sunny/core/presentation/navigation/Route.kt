package hu.blu3berry.sunny.core.presentation.navigation

import kotlinx.serialization.Serializable

sealed interface Route {

    @Serializable
    data object FoodList : Route
    @Serializable
    data object FoodDetail : Route

}