package hu.blu3berry.sunny.features.food.domain.model

data class Quantity(
    val amount: Double,
    val unit: UnitOfMeasure
)
