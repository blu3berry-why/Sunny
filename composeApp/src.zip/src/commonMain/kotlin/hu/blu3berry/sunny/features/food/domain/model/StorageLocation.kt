package hu.blu3berry.sunny.features.food.domain.model

enum class StorageLocation {
    FRIDGE, FREEZER, PANTRY, OTHER
}
