package hu.blu3berry.sunny.features.food.domain.model

enum class FoodCategory {
    DAIRY, MEAT, VEGETABLE, FRUIT, GRAIN, SNACK, DRINK, OTHER
}
