package hu.blu3berry.sunny.database.di

import org.koin.core.module.Module

expect val DatabaseModule: Module