package hu.blu3berry.sunny.features.food.domain.model

enum class MissingReason {
    OUT_OF_STOCK, BELOW_MINIMUM, USER_REQUESTED
}
