package hu.blu3berry.sunny.core.domain

interface Error
