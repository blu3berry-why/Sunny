package hu.blu3berry.sunny.features.food.domain.model

enum class UnitOfMeasure {
    PIECE, GRAM, KILOGRAM, MILLILITER, LITER, PACKAGE
}
