package hu.blu3berry.sunny.core.data

actual fun isErrorUnknownHostException(e: Exception): Boolean {
    return false
}